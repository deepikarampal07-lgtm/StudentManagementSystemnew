# Student Management System - Next Level GUI

This version adds a professional Swing UI around the existing MySQL/JDBC project.

## Features
- Login screen (demo credentials: `admin` / `admin123`)
- Dashboard with total student count and system status
- Add Student popup
- Edit Student popup
- Delete selected student
- Search by name, course, email or phone
- Dark/light mode toggle
- Colorful professional buttons and cards
- Existing `StudentDAO`, `Student`, and `DBConnection` database logic preserved

## Run
1. Keep MySQL Server running.
2. Make sure `DBConnection.java` contains your actual MySQL password.
3. Keep MySQL Connector/J `.jar` in the IntelliJ project libraries.
4. Run `StudentManagementGUI.java`.
5. Login with `admin` / `admin123`.
